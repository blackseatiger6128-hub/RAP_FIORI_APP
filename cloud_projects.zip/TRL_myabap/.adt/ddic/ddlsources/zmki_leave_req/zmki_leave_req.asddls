@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Leave requests manage'
@Metadata.ignorePropagatedAnnotations: true
define root view entity ZMKI_LEAVE_REQ as select from zmkdb_leave_req 
{
   key leave_uuid as LeaveUuid, 
   employee_id as EmployeeId, 
   start_date as StartDate, 
   end_date as EndDate, 
   duration_type as DurationType,
   leave_type as LeaveType, 
   reason as Reason, 
   approver_id as ApproverId, 
   status as Status,
   created_by as CreatedBy, 
   created_at as CreatedAt, 
   last_changed_by as LastChangedBy, 
   last_changed_at as LastChangedAt,
   local_last_changed_at as LocalLastChangedAt
}
