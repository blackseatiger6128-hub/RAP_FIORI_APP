@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Material Type VH Interface View'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZMKI_WM_MATERIALTYPE as select from zmk_t_wm_vhmat
{
    key material_type as MaterialType,
    description as Description
}
