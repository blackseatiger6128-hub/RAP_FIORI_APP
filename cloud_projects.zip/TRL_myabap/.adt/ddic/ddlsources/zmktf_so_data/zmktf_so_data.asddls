@EndUserText.label: 'CDS table function for so data'
@ClientHandling.type: #CLIENT_DEPENDENT
@ClientHandling.algorithm: #SESSION_VARIABLE
@ClientHandling.clientSafe: true
@AccessControl.authorizationCheck: #NOT_REQUIRED 
define table function ZMKTF_SO_DATA
with parameters p_maxrows: abap.int4
returns {
  client: abap.clnt;
  SalesOrder : abap.char( 10 );
  SalesOrderItem : abap.numc( 6 );
  Material: abap.char(40);
  NetValue: abap.curr(15,2);
  Currency: abap.cuky;
}
implemented by method zmkcl_so_tf=>get_data;