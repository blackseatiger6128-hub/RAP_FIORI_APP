@EndUserText.label: 'Cancellation Reason parameter'
define abstract entity ZMKAE_SP_CANCELLATION_REASON
{
    @EndUserText.label:'Cancellation Reason'
    //@ObjectModel.mandatory: true 
    CancellationReason:abap.char(255);
}
