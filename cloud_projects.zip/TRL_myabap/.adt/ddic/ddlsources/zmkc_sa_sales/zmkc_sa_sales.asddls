@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Consumption view of Sales Order'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZMKC_SA_SALES //with parameters p_maxrows: abap.int4 
    as select from ZMKC_SO_DATA1 //( p_maxrows: $parameters.p_maxrows )
{
    key SalesOrder,
    SalesOrderItem,
    Material,
    @Semantics.amount.currencyCode: 'Currency'
    NetValue,
    Currency
}
//where $parameters.p_maxrows = 5
