@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Leave Requests consumption'
@Metadata.ignorePropagatedAnnotations: true
define root view entity ZMKC_LEAVE_REQ
  as projection on ZMKI_LEAVE_REQ
{
      @UI.facet: [ { id:          'LeaveReq',
                   purpose:         #STANDARD,
                   type:            #IDENTIFICATION_REFERENCE,
                   label:           'Leave Requests ',
                   position:        10 } ]

      @UI.hidden: true
  key LeaveUuid,
      @UI: {
         lineItem:       [ { position: 10, importance: #HIGH } ],
         identification: [ { position: 10, label: 'Employee No.' } ] }
      @EndUserText: { label: 'Employee No.', quickInfo: 'Employee Number as per records' }
      @Search.defaultSearchElement: true
      EmployeeId,
      @UI: {
        lineItem:       [ { position: 20, importance: #MEDIUM } ],
        identification: [ { position: 20, label: 'Start Date' } ],
        selectionField: [ { position: 20 } ] }
      @EndUserText: { label: 'Start Date' }
      StartDate,
      @UI: {
        lineItem:       [ { position: 30, importance: #MEDIUM } ],
        identification: [ { position: 30, label: 'End Date' } ],
        selectionField: [ { position: 30 } ] }
      @EndUserText: { label: 'End Date' }
      EndDate,
      @UI: {
        lineItem:       [ { position: 40, importance: #HIGH } ],
        identification: [ { position: 40, label: 'Duration Type' } ],
        selectionField: [ { position: 40 } ] }
      @EndUserText: { label: 'Duration Type' }
      @Consumption.valueHelpDefinition: [{ entity : {name: 'ZMKI_DURATIONTYPE_VH', element: 'Code'  } }]
      @Search.defaultSearchElement: true
      @Search.fuzzinessThreshold: 0.8
      @Search.ranking: #MEDIUM
      DurationType,
      @UI: {
        lineItem:       [ { position: 50, importance: #HIGH } ],
        identification: [ { position: 50, label: 'Leave Type' } ],
        selectionField: [ { position: 50 } ] }
      @EndUserText: { label: 'Leave Type' }
      @Consumption.valueHelpDefinition: [{ entity : {name: 'ZMKI_LEAVETYPE_VH', element: 'Code'  } }]
      @Search.defaultSearchElement: true
      @Search.fuzzinessThreshold: 0.8
      @Search.ranking: #MEDIUM
      LeaveType,
      @UI.lineItem: [{ position: 60 }]
      @UI.identification: [{ position: 60, label: 'Reason' }]
      @EndUserText: { label: 'Reason' }
      Reason,
      @UI.lineItem: [{ position: 70 }]
      @UI.identification: [{ position: 70, label: 'Approver ID' }]
      @EndUserText: { label: 'Approver ID' }
      ApproverId,
      @UI.lineItem: [{ position: 80 }]
      @UI.identification: [{ position: 80, label: 'Status' }]
      @EndUserText: { label: 'Status' }
      Status,
      // --- Action Buttons UI Annotations ---
      @UI.lineItem: [
        { position: 10, label: 'Submit', type: #FOR_ACTION, dataAction: 'Submit' },
        { position: 20, label: 'Approve', type: #FOR_ACTION, dataAction: 'Approve' },
        { position: 30, label: 'Reject', type: #FOR_ACTION, dataAction: 'Reject' },
        { position: 40, label: 'Cancel', type: #FOR_ACTION, dataAction: 'Cancel' }
      ]
      @UI.identification: [
        { position: 10, label: 'Submit', type: #FOR_ACTION, dataAction: 'Submit' },
        { position: 20, label: 'Approve', type: #FOR_ACTION, dataAction: 'Approve' },
        { position: 30, label: 'Reject', type: #FOR_ACTION, dataAction: 'Reject' },
        { position: 40, label: 'Cancel', type: #FOR_ACTION, dataAction: 'Cancel' }
      ]
      @UI.hidden: true
      CreatedBy,
      @UI.hidden: true
      CreatedAt,
      @UI.hidden: true
      LastChangedBy,
      @UI.hidden: true
      LastChangedAt,
      @UI.hidden: true
      LocalLastChangedAt
}
