@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Warehouse Type Value Help'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZMKI_WM_WAREHOUSETYPE as select from zmk_t_wm_vhwhtyp
{
    key warehouse_type as WarehouseType,
    description as Description
}
