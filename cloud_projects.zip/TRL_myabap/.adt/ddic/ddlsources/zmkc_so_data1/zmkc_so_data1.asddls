@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Composite view of Sales Order'
@Metadata.ignorePropagatedAnnotations: true
define view entity ZMKC_SO_DATA1 //as select from ZMKI_SO_DATA1 as so_data
//with parameters p_maxrows: abap.int4
as select from ZMKTF_SO_DATA( p_maxrows: 5 ) //$parameters.p_maxrows )
{ 
    key SalesOrder,
    //key so_data._item.posnr as ItemID,

    //Erdat,
    //Audat,
    //Vbtyp,
    //Auart,
    //Vkorg,
    SalesOrderItem,
    Material,
    @Semantics.amount.currencyCode: 'Currency'
    NetValue,
    Currency
  
//    so_data._item.matnr as Matnr,
//    so_data._item.matkl as Matkl,
//    so_data._item.meins as Meins,
//    so_data._item.vrkme as Vrkme,
//    @DefaultAggregation: #SUM
//    @Semantics.quantity.unitOfMeasure: 'Gewei'
//    so_data._item.ntgew as Ntgew,
//    so_data._item.gewei as Gewei,
//    @DefaultAggregation: #SUM
//    @Semantics.amount.currencyCode: 'Waerk'
//    so_data._item.netwr as Netwr,
//    so_data._item.waerk as Waerk
    
}
