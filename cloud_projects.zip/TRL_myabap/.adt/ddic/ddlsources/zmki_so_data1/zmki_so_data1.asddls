@AbapCatalog.viewEnhancementCategory: [#NONE]
@AccessControl.authorizationCheck: #NOT_REQUIRED
@EndUserText.label: 'Sales Order Data'
@Metadata.ignorePropagatedAnnotations: true
@ObjectModel.usageType.dataClass: #MIXED
@ObjectModel.usageType.serviceQuality: #X
@ObjectModel.usageType.sizeCategory: #S
@VDM.viewType: #BASIC
define view entity ZMKI_SO_DATA1 as select from zmkt_soh as hdr
  association[1..*] to zmkt_soi as _item on 
    $projection.Vbeln = _item.vbeln
{
   key hdr.vbeln as Vbeln,
   hdr.erdat as Erdat,
   hdr.audat as Audat,
   hdr.vbtyp as Vbtyp,
   hdr.auart as Auart,
   hdr.vkorg as Vkorg,
   _item
}
